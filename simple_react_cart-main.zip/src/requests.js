

const requests = {
    fetchStore: "store/web/details/store1"
}

export default requests;
